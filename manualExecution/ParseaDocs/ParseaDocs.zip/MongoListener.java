// Generated from Mongo.g4 by ANTLR 4.8
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link MongoParser}.
 */
public interface MongoListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link MongoParser#prog}.
	 * @param ctx the parse tree
	 */
	void enterProg(MongoParser.ProgContext ctx);
	/**
	 * Exit a parse tree produced by {@link MongoParser#prog}.
	 * @param ctx the parse tree
	 */
	void exitProg(MongoParser.ProgContext ctx);
	/**
	 * Enter a parse tree produced by {@link MongoParser#main}.
	 * @param ctx the parse tree
	 */
	void enterMain(MongoParser.MainContext ctx);
	/**
	 * Exit a parse tree produced by {@link MongoParser#main}.
	 * @param ctx the parse tree
	 */
	void exitMain(MongoParser.MainContext ctx);
	/**
	 * Enter a parse tree produced by {@link MongoParser#arrayElement}.
	 * @param ctx the parse tree
	 */
	void enterArrayElement(MongoParser.ArrayElementContext ctx);
	/**
	 * Exit a parse tree produced by {@link MongoParser#arrayElement}.
	 * @param ctx the parse tree
	 */
	void exitArrayElement(MongoParser.ArrayElementContext ctx);
	/**
	 * Enter a parse tree produced by {@link MongoParser#array}.
	 * @param ctx the parse tree
	 */
	void enterArray(MongoParser.ArrayContext ctx);
	/**
	 * Exit a parse tree produced by {@link MongoParser#array}.
	 * @param ctx the parse tree
	 */
	void exitArray(MongoParser.ArrayContext ctx);
	/**
	 * Enter a parse tree produced by {@link MongoParser#doc}.
	 * @param ctx the parse tree
	 */
	void enterDoc(MongoParser.DocContext ctx);
	/**
	 * Exit a parse tree produced by {@link MongoParser#doc}.
	 * @param ctx the parse tree
	 */
	void exitDoc(MongoParser.DocContext ctx);
	/**
	 * Enter a parse tree produced by {@link MongoParser#json}.
	 * @param ctx the parse tree
	 */
	void enterJson(MongoParser.JsonContext ctx);
	/**
	 * Exit a parse tree produced by {@link MongoParser#json}.
	 * @param ctx the parse tree
	 */
	void exitJson(MongoParser.JsonContext ctx);
	/**
	 * Enter a parse tree produced by {@link MongoParser#tuples}.
	 * @param ctx the parse tree
	 */
	void enterTuples(MongoParser.TuplesContext ctx);
	/**
	 * Exit a parse tree produced by {@link MongoParser#tuples}.
	 * @param ctx the parse tree
	 */
	void exitTuples(MongoParser.TuplesContext ctx);
	/**
	 * Enter a parse tree produced by {@link MongoParser#key}.
	 * @param ctx the parse tree
	 */
	void enterKey(MongoParser.KeyContext ctx);
	/**
	 * Exit a parse tree produced by {@link MongoParser#key}.
	 * @param ctx the parse tree
	 */
	void exitKey(MongoParser.KeyContext ctx);
	/**
	 * Enter a parse tree produced by {@link MongoParser#value}.
	 * @param ctx the parse tree
	 */
	void enterValue(MongoParser.ValueContext ctx);
	/**
	 * Exit a parse tree produced by {@link MongoParser#value}.
	 * @param ctx the parse tree
	 */
	void exitValue(MongoParser.ValueContext ctx);
}