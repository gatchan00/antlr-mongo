// Generated from Mongo.g4 by ANTLR 4.8
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class MongoParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.8", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, T__4=5, T__5=6, T__6=7, T__7=8, NEWLINE=9, 
		INT=10, FLOAT=11, WORD=12, WORDSPACE=13, COMMAND=14, AGGCMD=15, ALPHANUM=16, 
		WHITES=17;
	public static final int
		RULE_prog = 0, RULE_main = 1, RULE_arrayElement = 2, RULE_array = 3, RULE_doc = 4, 
		RULE_json = 5, RULE_tuples = 6, RULE_key = 7, RULE_value = 8;
	private static String[] makeRuleNames() {
		return new String[] {
			"prog", "main", "arrayElement", "array", "doc", "json", "tuples", "key", 
			"value"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "'['", "','", "']'", "'Document'", "'{'", "'}'", "'='", "'\"'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, null, null, null, null, null, null, null, null, "NEWLINE", "INT", 
			"FLOAT", "WORD", "WORDSPACE", "COMMAND", "AGGCMD", "ALPHANUM", "WHITES"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "Mongo.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public MongoParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	public static class ProgContext extends ParserRuleContext {
		public MainContext main() {
			return getRuleContext(MainContext.class,0);
		}
		public TerminalNode NEWLINE() { return getToken(MongoParser.NEWLINE, 0); }
		public TerminalNode WHITES() { return getToken(MongoParser.WHITES, 0); }
		public ProgContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_prog; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof MongoListener ) ((MongoListener)listener).enterProg(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof MongoListener ) ((MongoListener)listener).exitProg(this);
		}
	}

	public final ProgContext prog() throws RecognitionException {
		ProgContext _localctx = new ProgContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_prog);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(18);
			main();
			setState(20);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==WHITES) {
				{
				setState(19);
				match(WHITES);
				}
			}

			setState(22);
			match(NEWLINE);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class MainContext extends ParserRuleContext {
		public DocContext doc() {
			return getRuleContext(DocContext.class,0);
		}
		public ArrayContext array() {
			return getRuleContext(ArrayContext.class,0);
		}
		public MainContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_main; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof MongoListener ) ((MongoListener)listener).enterMain(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof MongoListener ) ((MongoListener)listener).exitMain(this);
		}
	}

	public final MainContext main() throws RecognitionException {
		MainContext _localctx = new MainContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_main);
		try {
			setState(26);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__3:
				enterOuterAlt(_localctx, 1);
				{
				setState(24);
				doc();
				}
				break;
			case T__0:
				enterOuterAlt(_localctx, 2);
				{
				setState(25);
				array();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ArrayElementContext extends ParserRuleContext {
		public DocContext doc() {
			return getRuleContext(DocContext.class,0);
		}
		public TerminalNode WORD() { return getToken(MongoParser.WORD, 0); }
		public TerminalNode FLOAT() { return getToken(MongoParser.FLOAT, 0); }
		public TerminalNode INT() { return getToken(MongoParser.INT, 0); }
		public TerminalNode COMMAND() { return getToken(MongoParser.COMMAND, 0); }
		public TerminalNode AGGCMD() { return getToken(MongoParser.AGGCMD, 0); }
		public ArrayContext array() {
			return getRuleContext(ArrayContext.class,0);
		}
		public ArrayElementContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_arrayElement; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof MongoListener ) ((MongoListener)listener).enterArrayElement(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof MongoListener ) ((MongoListener)listener).exitArrayElement(this);
		}
	}

	public final ArrayElementContext arrayElement() throws RecognitionException {
		ArrayElementContext _localctx = new ArrayElementContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_arrayElement);
		try {
			setState(35);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case T__3:
				enterOuterAlt(_localctx, 1);
				{
				setState(28);
				doc();
				}
				break;
			case WORD:
				enterOuterAlt(_localctx, 2);
				{
				setState(29);
				match(WORD);
				}
				break;
			case FLOAT:
				enterOuterAlt(_localctx, 3);
				{
				setState(30);
				match(FLOAT);
				}
				break;
			case INT:
				enterOuterAlt(_localctx, 4);
				{
				setState(31);
				match(INT);
				}
				break;
			case COMMAND:
				enterOuterAlt(_localctx, 5);
				{
				setState(32);
				match(COMMAND);
				}
				break;
			case AGGCMD:
				enterOuterAlt(_localctx, 6);
				{
				setState(33);
				match(AGGCMD);
				}
				break;
			case T__0:
				enterOuterAlt(_localctx, 7);
				{
				setState(34);
				array();
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ArrayContext extends ParserRuleContext {
		public List<ArrayElementContext> arrayElement() {
			return getRuleContexts(ArrayElementContext.class);
		}
		public ArrayElementContext arrayElement(int i) {
			return getRuleContext(ArrayElementContext.class,i);
		}
		public List<TerminalNode> WHITES() { return getTokens(MongoParser.WHITES); }
		public TerminalNode WHITES(int i) {
			return getToken(MongoParser.WHITES, i);
		}
		public ArrayContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_array; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof MongoListener ) ((MongoListener)listener).enterArray(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof MongoListener ) ((MongoListener)listener).exitArray(this);
		}
	}

	public final ArrayContext array() throws RecognitionException {
		ArrayContext _localctx = new ArrayContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_array);
		int _la;
		try {
			int _alt;
			setState(53);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,5,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(37);
				match(T__0);
				setState(45);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,4,_ctx);
				while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
					if ( _alt==1 ) {
						{
						{
						setState(38);
						arrayElement();
						setState(39);
						match(T__1);
						setState(41);
						_errHandler.sync(this);
						_la = _input.LA(1);
						if (_la==WHITES) {
							{
							setState(40);
							match(WHITES);
							}
						}

						}
						} 
					}
					setState(47);
					_errHandler.sync(this);
					_alt = getInterpreter().adaptivePredict(_input,4,_ctx);
				}
				setState(48);
				arrayElement();
				setState(49);
				match(T__2);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(51);
				match(T__0);
				setState(52);
				match(T__2);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DocContext extends ParserRuleContext {
		public JsonContext json() {
			return getRuleContext(JsonContext.class,0);
		}
		public DocContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_doc; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof MongoListener ) ((MongoListener)listener).enterDoc(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof MongoListener ) ((MongoListener)listener).exitDoc(this);
		}
	}

	public final DocContext doc() throws RecognitionException {
		DocContext _localctx = new DocContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_doc);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(55);
			match(T__3);
			setState(56);
			match(T__4);
			setState(57);
			json();
			setState(58);
			match(T__5);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class JsonContext extends ParserRuleContext {
		public TuplesContext tuples() {
			return getRuleContext(TuplesContext.class,0);
		}
		public JsonContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_json; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof MongoListener ) ((MongoListener)listener).enterJson(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof MongoListener ) ((MongoListener)listener).exitJson(this);
		}
	}

	public final JsonContext json() throws RecognitionException {
		JsonContext _localctx = new JsonContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_json);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(60);
			match(T__4);
			setState(61);
			tuples();
			setState(62);
			match(T__5);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TuplesContext extends ParserRuleContext {
		public List<KeyContext> key() {
			return getRuleContexts(KeyContext.class);
		}
		public KeyContext key(int i) {
			return getRuleContext(KeyContext.class,i);
		}
		public List<ValueContext> value() {
			return getRuleContexts(ValueContext.class);
		}
		public ValueContext value(int i) {
			return getRuleContext(ValueContext.class,i);
		}
		public List<TerminalNode> WHITES() { return getTokens(MongoParser.WHITES); }
		public TerminalNode WHITES(int i) {
			return getToken(MongoParser.WHITES, i);
		}
		public TuplesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_tuples; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof MongoListener ) ((MongoListener)listener).enterTuples(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof MongoListener ) ((MongoListener)listener).exitTuples(this);
		}
	}

	public final TuplesContext tuples() throws RecognitionException {
		TuplesContext _localctx = new TuplesContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_tuples);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(73);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,7,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					{
					{
					setState(64);
					key();
					setState(65);
					match(T__6);
					setState(66);
					value();
					setState(67);
					match(T__1);
					setState(69);
					_errHandler.sync(this);
					_la = _input.LA(1);
					if (_la==WHITES) {
						{
						setState(68);
						match(WHITES);
						}
					}

					}
					} 
				}
				setState(75);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,7,_ctx);
			}
			setState(76);
			key();
			setState(77);
			match(T__6);
			setState(78);
			value();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class KeyContext extends ParserRuleContext {
		public TerminalNode WORD() { return getToken(MongoParser.WORD, 0); }
		public TerminalNode COMMAND() { return getToken(MongoParser.COMMAND, 0); }
		public KeyContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_key; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof MongoListener ) ((MongoListener)listener).enterKey(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof MongoListener ) ((MongoListener)listener).exitKey(this);
		}
	}

	public final KeyContext key() throws RecognitionException {
		KeyContext _localctx = new KeyContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_key);
		try {
			setState(88);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,8,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(80);
				match(WORD);
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(81);
				match(T__7);
				setState(82);
				match(WORD);
				setState(83);
				match(T__7);
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(84);
				match(COMMAND);
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				setState(85);
				match(T__7);
				setState(86);
				match(COMMAND);
				setState(87);
				match(T__7);
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ValueContext extends ParserRuleContext {
		public TerminalNode WORDSPACE() { return getToken(MongoParser.WORDSPACE, 0); }
		public TerminalNode INT() { return getToken(MongoParser.INT, 0); }
		public TerminalNode ALPHANUM() { return getToken(MongoParser.ALPHANUM, 0); }
		public TerminalNode FLOAT() { return getToken(MongoParser.FLOAT, 0); }
		public ArrayContext array() {
			return getRuleContext(ArrayContext.class,0);
		}
		public DocContext doc() {
			return getRuleContext(DocContext.class,0);
		}
		public TerminalNode COMMAND() { return getToken(MongoParser.COMMAND, 0); }
		public TerminalNode AGGCMD() { return getToken(MongoParser.AGGCMD, 0); }
		public ValueContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_value; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof MongoListener ) ((MongoListener)listener).enterValue(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof MongoListener ) ((MongoListener)listener).exitValue(this);
		}
	}

	public final ValueContext value() throws RecognitionException {
		ValueContext _localctx = new ValueContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_value);
		try {
			setState(98);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case WORDSPACE:
				enterOuterAlt(_localctx, 1);
				{
				setState(90);
				match(WORDSPACE);
				}
				break;
			case INT:
				enterOuterAlt(_localctx, 2);
				{
				setState(91);
				match(INT);
				}
				break;
			case ALPHANUM:
				enterOuterAlt(_localctx, 3);
				{
				setState(92);
				match(ALPHANUM);
				}
				break;
			case FLOAT:
				enterOuterAlt(_localctx, 4);
				{
				setState(93);
				match(FLOAT);
				}
				break;
			case T__0:
				enterOuterAlt(_localctx, 5);
				{
				setState(94);
				array();
				}
				break;
			case T__3:
				enterOuterAlt(_localctx, 6);
				{
				setState(95);
				doc();
				}
				break;
			case COMMAND:
				enterOuterAlt(_localctx, 7);
				{
				setState(96);
				match(COMMAND);
				}
				break;
			case AGGCMD:
				enterOuterAlt(_localctx, 8);
				{
				setState(97);
				match(AGGCMD);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\23g\4\2\t\2\4\3\t"+
		"\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\3\2\3\2\5\2"+
		"\27\n\2\3\2\3\2\3\3\3\3\5\3\35\n\3\3\4\3\4\3\4\3\4\3\4\3\4\3\4\5\4&\n"+
		"\4\3\5\3\5\3\5\3\5\5\5,\n\5\7\5.\n\5\f\5\16\5\61\13\5\3\5\3\5\3\5\3\5"+
		"\3\5\5\58\n\5\3\6\3\6\3\6\3\6\3\6\3\7\3\7\3\7\3\7\3\b\3\b\3\b\3\b\3\b"+
		"\5\bH\n\b\7\bJ\n\b\f\b\16\bM\13\b\3\b\3\b\3\b\3\b\3\t\3\t\3\t\3\t\3\t"+
		"\3\t\3\t\3\t\5\t[\n\t\3\n\3\n\3\n\3\n\3\n\3\n\3\n\3\n\5\ne\n\n\3\n\2\2"+
		"\13\2\4\6\b\n\f\16\20\22\2\2\2t\2\24\3\2\2\2\4\34\3\2\2\2\6%\3\2\2\2\b"+
		"\67\3\2\2\2\n9\3\2\2\2\f>\3\2\2\2\16K\3\2\2\2\20Z\3\2\2\2\22d\3\2\2\2"+
		"\24\26\5\4\3\2\25\27\7\23\2\2\26\25\3\2\2\2\26\27\3\2\2\2\27\30\3\2\2"+
		"\2\30\31\7\13\2\2\31\3\3\2\2\2\32\35\5\n\6\2\33\35\5\b\5\2\34\32\3\2\2"+
		"\2\34\33\3\2\2\2\35\5\3\2\2\2\36&\5\n\6\2\37&\7\16\2\2 &\7\r\2\2!&\7\f"+
		"\2\2\"&\7\20\2\2#&\7\21\2\2$&\5\b\5\2%\36\3\2\2\2%\37\3\2\2\2% \3\2\2"+
		"\2%!\3\2\2\2%\"\3\2\2\2%#\3\2\2\2%$\3\2\2\2&\7\3\2\2\2\'/\7\3\2\2()\5"+
		"\6\4\2)+\7\4\2\2*,\7\23\2\2+*\3\2\2\2+,\3\2\2\2,.\3\2\2\2-(\3\2\2\2.\61"+
		"\3\2\2\2/-\3\2\2\2/\60\3\2\2\2\60\62\3\2\2\2\61/\3\2\2\2\62\63\5\6\4\2"+
		"\63\64\7\5\2\2\648\3\2\2\2\65\66\7\3\2\2\668\7\5\2\2\67\'\3\2\2\2\67\65"+
		"\3\2\2\28\t\3\2\2\29:\7\6\2\2:;\7\7\2\2;<\5\f\7\2<=\7\b\2\2=\13\3\2\2"+
		"\2>?\7\7\2\2?@\5\16\b\2@A\7\b\2\2A\r\3\2\2\2BC\5\20\t\2CD\7\t\2\2DE\5"+
		"\22\n\2EG\7\4\2\2FH\7\23\2\2GF\3\2\2\2GH\3\2\2\2HJ\3\2\2\2IB\3\2\2\2J"+
		"M\3\2\2\2KI\3\2\2\2KL\3\2\2\2LN\3\2\2\2MK\3\2\2\2NO\5\20\t\2OP\7\t\2\2"+
		"PQ\5\22\n\2Q\17\3\2\2\2R[\7\16\2\2ST\7\n\2\2TU\7\16\2\2U[\7\n\2\2V[\7"+
		"\20\2\2WX\7\n\2\2XY\7\20\2\2Y[\7\n\2\2ZR\3\2\2\2ZS\3\2\2\2ZV\3\2\2\2Z"+
		"W\3\2\2\2[\21\3\2\2\2\\e\7\17\2\2]e\7\f\2\2^e\7\22\2\2_e\7\r\2\2`e\5\b"+
		"\5\2ae\5\n\6\2be\7\20\2\2ce\7\21\2\2d\\\3\2\2\2d]\3\2\2\2d^\3\2\2\2d_"+
		"\3\2\2\2d`\3\2\2\2da\3\2\2\2db\3\2\2\2dc\3\2\2\2e\23\3\2\2\2\f\26\34%"+
		"+/\67GKZd";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}